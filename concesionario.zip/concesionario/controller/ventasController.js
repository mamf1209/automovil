const ventasModel = require('../model/ventas');

// Obtener todas las ventas
exports.getVentas = async (req, res) => {
  try {
    const ventas = await ventasModel.getVentas();
    res.json(ventas);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Obtener una venta por ID
exports.getVentaById = async (req, res) => {
  const { id } = req.params;
  try {
    const venta = await ventasModel.getVentaById(id);
    if (venta) {
      res.json(venta);
    } else {
      res.status(404).json({ message: 'Venta no encontrada' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Obtener ventas por texto
exports.getVentasByText = async (req, res) => {
  const { text } = req.params;
  try {
    const ventas = await ventasModel.getVentasByText(text);
    if (ventas.length > 0) {
      res.json(ventas);
    } else {
      res.status(404).json({ message: 'No se encontraron ventas' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};


exports.addVenta = async (req, res) => {
  const {
    NumeroBastidor,
    VendedoresId,
    ServiciosId,
    ClienteId,
    PrecioCobrado,
    ModoPago,
    FechaEntrega,
    Matricula,
    StockFabricado
  } = req.body;

  try {
    // Validar que los IDs sean válidos y existan
    if (!(await ventasModel.validateNumeroBastidor(NumeroBastidor)) ||
        !(await ventasModel.validateVendedor(VendedoresId)) ||
        !(await ventasModel.validateServicio(ServiciosId)) ||
        !(await ventasModel.validateCliente(ClienteId))) {
      return res.status(400).json({ error: 'Datos inválidos' });
    }

    // Agregar la venta
    const nuevaVenta = await ventasModel.createVenta({
      NumeroBastidor,
      VendedoresId,
      ServiciosId,
      ClienteId,
      PrecioCobrado,
      ModoPago,
      FechaEntrega,
      Matricula,
      StockFabricado
    });

    res.status(201).json({ message: 'Venta guardada con éxito', venta: nuevaVenta });
  } catch (error) {
    console.error('Error al guardar la venta:', error);
    res.status(500).json({ error: 'Error al guardar la venta' });
  }
};



// Actualizar una venta por ID
exports.updateVenta = async (req, res) => {
  const { id } = req.params;
  try {
    const venta = await ventasModel.updateVenta(id, req.body);
    if (venta) {
      res.json(venta);
    } else {
      res.status(404).json({ message: 'Venta no encontrada' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Eliminar una venta por ID
exports.deleteVenta = async (req, res) => {
  const { id } = req.params;
  try {
    const venta = await ventasModel.deleteVenta(id);
    if (venta) {
      res.json(venta);
    } else {
      res.status(404).json({ message: 'Venta no encontrada' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Validar Número Bastidor
exports.validateNumeroBastidor = async (req, res) => {
  const { id } = req.params;
  try {
    const valid = await ventasModel.validateNumeroBastidor(id);
    if (valid) {
      res.json(valid);
    } else {
      res.status(404).json({ message: 'Número Bastidor no válido' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Validar Vendedor
exports.validateVendedor = async (req, res) => {
  const { id } = req.params;
  try {
    const valid = await ventasModel.validateVendedor(id);
    if (valid) {
      res.json(valid);
    } else {
      res.status(404).json({ message: 'Vendedor no válido' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Validar Servicio
exports.validateServicio = async (req, res) => {
  const { id } = req.params;
  try {
    const valid = await ventasModel.validateServicio(id);
    if (valid) {
      res.json(valid);
    } else {
      res.status(404).json({ message: 'Servicio no válido' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Validar Cliente
exports.validateCliente = async (req, res) => {
  const { id } = req.params;
  try {
    const valid = await ventasModel.validateCliente(id);
    if (valid) {
      res.json(valid);
    } else {
      res.status(404).json({ message: 'Cliente no válido' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Obtener todos los vendedores
exports.getVendedores = async (req, res) => {
  try {
    const vendedores = await ventasModel.getVendedores();
    res.json(vendedores);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Obtener todos los servicios
exports.getServicios = async (req, res) => {
  try {
    const servicios = await ventasModel.getServicios();
    res.json(servicios);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Obtener todos los automóviles
exports.getAutos = async (req, res) => {
  try {
    const autos = await ventasModel.getAutos();
    res.json(autos);
  } catch (error) {
    console.error('Error al obtener los automóviles:', error);
    res.status(500).json({ error: error.message });
  }
};

// Obtener todos los clientes
exports.getClientes = async (req, res) => {
  try {
    const clientes = await ventasModel.getClientes();
    res.json(clientes);
  } catch (error) {
    console.error('Error al obtener los clientes:', error);
    res.status(500).json({ error: error.message });
  }
};
