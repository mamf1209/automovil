Create table Modelo(
	ModeloId serial primary key,
	Nombre varchar(25),
	Marca varchar(25));

Create table Cliente(
	ClienteId serial primary key,
	Nombre varchar(25),
	Domicilio varchar(25),
	Telefono varchar(12),
	Email varchar(20));

Create table Vendedores(
	VendedoresId serial PRIMARY KEY,
	Nombre varchar(25),
	Domicilio varchar(25),
	Nif int, 
	Telefono varchar(12), 
	Email varchar(20));

Create table ServiciosOficiales (
	ServiciosId serial PRIMARY KEY,
	Nombre varchar(25),
	Nif int,
	Domicilio varchar(25) );

Create table Automovil(
	NumeroBastidor serial primary key,
	Marca varchar(25),
	ModeloId int,
	Descuento int,
	Pago float,
	PotenciaFiscal float,
	Cilindrada float,
	Estado varchar(20),
	Constraint fkModeloId foreign key(ModeloId)  references Modelo(ModeloId));   


create table EquipamientoExtra(
	ExtraId serial primary key,
	ModeloId int,
	PrecioExtra float,
	EquipExtra varchar(20),
	constraint fkModeloId foreign key(ModeloId) references Modelo(ModeloId));

create table EquipamientoSerie(
	SerieId serial primary key,
	ModeloId int,
	Caracteristicas varchar(20),
	constraint fkModeloId foreign key(ModeloId) references Modelo(ModeloId));

CREATE TABLE VentasRealizadas (
    VentasId serial primary key,
	NumeroBastidor int,
	VendedoresId int,
	ServiciosId int,
	ClienteId int,
    PrecioCobrado float,
    ModoPago varchar,
    FechaEntrega date,
    Matricula varchar,
    StockFabricado int,
	constraint fkNumeroBastidor foreign key(NumeroBastidor) references Automovil(NumeroBastidor), 
	constraint fkVendedoresId foreign key(VendedoresID) references Vendedores(VendedoresId),
	constraint fkServiciosId foreign key(ServiciosId) references ServiciosOficiales(ServiciosId),
	constraint fkClienteId foreign key(ClienteId) references Cliente(ClienteId)
	);

Select * From VentasRealizadas;

Select * From EquipamientoSerie;

Select * From EquipamientoExtra;

Select * From ServiciosOficiales;

Select * from Vendedores;

Select * From Cliente;

