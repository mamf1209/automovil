// models/ventas.js
const pool = require('./database');

// Obtener todas las ventas
const getVentas = async () => {
  const res = await pool.query('SELECT * FROM VentasRealizadas');
  return res.rows;
};

// Obtener una venta por ID
const getVentaById = async (id) => {
  const res = await pool.query('SELECT * FROM VentasRealizadas WHERE VentasId = $1', [id]);
  return res.rows[0];
};

// Obtener ventas por texto
const getVentasByText = async (text) => {
  const queryText = `%${text}%`;
  const res = await pool.query(`
    SELECT * FROM VentasRealizadas
    WHERE CAST(VentasId AS TEXT) ILIKE $1
    OR CAST(NumeroBastidor AS TEXT) ILIKE $1
    OR CAST(VendedoresId AS TEXT) ILIKE $1
    OR CAST(ServiciosId AS TEXT) ILIKE $1
    OR CAST(ClienteId AS TEXT) ILIKE $1
    OR CAST(PrecioCobrado AS TEXT) ILIKE $1
    OR CAST(ModoPago AS TEXT) ILIKE $1
    OR TO_CHAR(FechaEntrega, 'YYYY-MM-DD') ILIKE $1
    OR CAST(Matricula AS TEXT) ILIKE $1
    OR CAST(StockFabricado AS TEXT) ILIKE $1
  `, [queryText]);
  return res.rows;
};

function deleteVenta(id) {
  if (confirm('¿Estás seguro de que quieres eliminar esta venta?')) {
    fetch(`/api/ventas/${id}`, {
      method: 'DELETE'
    })
      .then(response => {
        if (response.ok) {
          alert('Venta eliminada');
          deleteVentaFromTable(id); // Eliminar la fila sin recargar la página
        } else {
          alert('Error al eliminar la venta');
        }
      })
      .catch(error => console.error('Error al eliminar la venta:', error));
  }
}

function deleteVentaFromTable(id) {
  const rows = document.querySelectorAll('#ventasTable tbody tr');
  rows.forEach(row => {
    if (row.cells[0].textContent == id) {
      row.remove();
    }
  });
}
  
const createVenta = async (venta) => {
  const { NumeroBastidor, VendedoresId, ServiciosId, ClienteId, PrecioCobrado, ModoPago, FechaEntrega, Matricula, StockFabricado } = venta;

  // Validar que todos los campos necesarios estén presentes
  if (!NumeroBastidor || !VendedoresId || !ServiciosId || !ClienteId || PrecioCobrado === undefined || StockFabricado === undefined) {
    throw new Error('Faltan datos necesarios o están mal formateados.');
  }

  try {
    const res = await pool.query(
      'INSERT INTO VentasRealizadas (NumeroBastidor, VendedoresId, ServiciosId, ClienteId, PrecioCobrado, ModoPago, FechaEntrega, Matricula, StockFabricado) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *',
      [NumeroBastidor, VendedoresId, ServiciosId, ClienteId, PrecioCobrado, ModoPago, FechaEntrega, Matricula, StockFabricado]
    );
    return res.rows[0];
  } catch (error) {
    console.error('Error al insertar en la base de datos:', error);
    throw error;
  }
};



// Actualizar una venta por ID
const updateVenta = async (id, venta) => {
  const { NumeroBastidor, VendedoresId, ServiciosId, ClienteId, PrecioCobrado, ModoPago, FechaEntrega, Matricula, StockFabricado } = venta;
  const res = await pool.query(
    'UPDATE VentasRealizadas SET NumeroBastidor = $1, VendedoresId = $2, ServiciosId = $3, ClienteId = $4, PrecioCobrado = $5, ModoPago = $6, FechaEntrega = $7, Matricula = $8, StockFabricado = $9 WHERE VentasId = $10 RETURNING *',
    [NumeroBastidor, VendedoresId, ServiciosId, ClienteId, PrecioCobrado, ModoPago, FechaEntrega, Matricula, StockFabricado, id]
  );
  return res.rows[0];
};



const validateNumeroBastidor = async (numeroBastidor) => {
  console.log('Validando Número Bastidor:', numeroBastidor); // Registro de depuración
  try {
    const result = await pool.query('SELECT 1 FROM Automovil WHERE NumeroBastidor = $1', [numeroBastidor]);
    console.log('Resultado de Validación:', result.rows.length); // Registro de depuración
    return result.rows.length > 0;
  } catch (error) {
    console.error('Error en validación de Número Bastidor:', error);
    throw error;
  }
};


const validateVendedor = async (vendedorId) => {
  const result = await pool.query('SELECT 1 FROM Vendedores WHERE VendedoresId = $1', [vendedorId]);
  return result.rows.length > 0;
};

const validateServicio = async (servicioId) => {
  const result = await pool.query('SELECT 1 FROM ServiciosOficiales WHERE ServiciosId = $1', [servicioId]);
  return result.rows.length > 0;
};

const validateCliente = async (clienteId) => {
  const result = await pool.query('SELECT 1 FROM Cliente WHERE ClienteId = $1', [clienteId]);
  return result.rows.length > 0;
};


// Obtener todos los vendedores
const getVendedores = async () => {
  const res = await pool.query('SELECT VendedoresId, Nombre FROM Vendedores');
  return res.rows;
};

// Obtener todos los servicios
const getServicios = async () => {
  const res = await pool.query('SELECT ServiciosId, Nombre FROM ServiciosOficiales');
  return res.rows;
};

// Obtener todos los automóviles (Número de Bastidor y Marca)
const getAutos = async () => {
  const res = await pool.query('SELECT NumeroBastidor, Marca FROM Automovil');
  return res.rows;
};

// Obtener todos los clientes
const getClientes = async () => {
  const res = await pool.query('SELECT ClienteId, Nombre FROM Cliente');
  return res.rows;
};

module.exports = {
  getVentas,
  getVentaById,
  getVentasByText,
  createVenta,
  updateVenta,
  deleteVenta,
  validateNumeroBastidor,
  validateVendedor,
  validateServicio,
  validateCliente,
  getVendedores,
  getServicios,
  getClientes,
  getAutos
 
};
