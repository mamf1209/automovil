const { Pool } = require('pg');

// Configuración de la conexión a la base de datos
const pool = new Pool({
  user: 'postgres',
  host: 'localhost', // o la dirección de tu servidor de base de datos
  database: 'ventas',
  password: '162004',
  port: 5432,
});

module.exports = pool;