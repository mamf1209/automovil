document.addEventListener('DOMContentLoaded', async () => {
  const vendedorSelect = document.getElementById('vendedor');
  const servicioSelect = document.getElementById('servicio');
  const clienteSelect = document.getElementById('cliente');
  const numeroBastidorSelect = document.getElementById('numeroBastidor');

  // Función para cargar y llenar las opciones de los combo boxes
  async function loadOptions(url, selectElement, valueKey, textKey) {
    try {
      // Limpiar el combo box
      selectElement.innerHTML = ''; 
      
      // Agregar la opción "Seleccionar"
      const defaultOption = document.createElement('option');
      defaultOption.value = '';
      defaultOption.textContent = `Seleccionar ${selectElement.id.replace(/([A-Z])/g, ' $1').toLowerCase()}`;
      selectElement.appendChild(defaultOption);
      
      // Obtener datos y llenarlos en el combo box
      const response = await fetch(url);
      const data = await response.json();
      data.forEach(item => {
        const option = document.createElement('option');
        option.value = item[valueKey]; // Valor será el ID
        option.textContent = item[textKey]; // Texto será el nombre o marca
        selectElement.appendChild(option);
      });
    } catch (error) {
      console.error('Error al cargar opciones:', error);
    }
  }

  // Cargar opciones para cada combo box
  await loadOptions('/api/vendedores', vendedorSelect, 'vendedoresid', 'nombre');
  await loadOptions('/api/servicios', servicioSelect, 'serviciosid', 'nombre');
  await loadOptions('/api/clientes', clienteSelect, 'clienteid', 'nombre');
  await loadOptions('/api/autos', numeroBastidorSelect, 'numerobastidor', 'marca');


  // Función para manejar el envío del formulario
  document.getElementById('ventaForm').addEventListener('submit', async (event) => {
    event.preventDefault();
  
    const formData = new FormData(event.target);
    const data = Object.fromEntries(formData.entries());
  
    console.log('Datos enviados:', data); // Agrega esta línea para depurar
  
    try {
      const response = await fetch('/api/ventas', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          NumeroBastidor: data.numeroBastidor,
          VendedoresId: data.vendedor,
          ServiciosId: data.servicio,
          ClienteId: data.cliente,
          PrecioCobrado: parseFloat(data.precioCobrado),
          ModoPago: data.modoPago,
          FechaEntrega: data.fechaEntrega,
          Matricula: data.matricula,
          StockFabricado: parseInt(data.stockFabricado, 10)
        }),
      });
  
      if (response.ok) {
        const result = await response.json();
        alert(result.message); // Mensaje de éxito
      } else {
        const error = await response.json();
        alert('Error: ' + error.error); // Mostrar error
      }
    } catch (error) {
      console.error('Error al enviar los datos:', error);
    }
  });
  
  
  if (cancelButton) {
    cancelButton.addEventListener('click', () => {
      ventaForm.reset();
      const vendedorSelect = document.getElementById('vendedor');
      const servicioSelect = document.getElementById('servicio');
      const clienteSelect = document.getElementById('cliente');
      const numeroBastidorSelect = document.getElementById('numeroBastidor');

      vendedorSelect.innerHTML = '<option value="">Seleccionar Vendedor</option>';
      servicioSelect.innerHTML = '<option value="">Seleccionar Servicio</option>';
      clienteSelect.innerHTML = '<option value="">Seleccionar Cliente</option>';
      numeroBastidorSelect.innerHTML = '<option value="">Seleccionar Marca de Automóvil</option>';

      window.location.reload();
    });
  }
});
