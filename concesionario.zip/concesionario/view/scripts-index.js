document.addEventListener('DOMContentLoaded', () => {
  // Cargar todas las ventas al cargar la página
  fetch('/api/ventas')
    .then(response => response.json())
    .then(data => {
      const tableBody = document.querySelector('#ventasTable tbody');
      tableBody.innerHTML = '';

      if (data.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="11">No se encontraron resultados.</td></tr>';
      } else {
        data.forEach(venta => {
          addVentaToTable(venta);
        });
      }
    })
    .catch(error => console.error('Error al cargar datos:', error));

  // Buscar por texto
  document.getElementById('searchButton').addEventListener('click', () => {
    const searchText = document.getElementById('searchInput').value.toLowerCase();
    fetch(`/api/ventas/text/${encodeURIComponent(searchText)}`)
      .then(response => response.json())
      .then(data => {
        const tableBody = document.querySelector('#ventasTable tbody');
        tableBody.innerHTML = '';

        if (data.length === 0) {
          tableBody.innerHTML = '<tr><td colspan="11">No se encontraron resultados.</td></tr>';
        } else {
          data.forEach(venta => {
            addVentaToTable(venta);
          });
        }
      })
      .catch(error => {
        console.error('Error al buscar ventas:', error);
        alert('Error al buscar ventas');
      });
  });

  // Buscar por ID
  document.getElementById('searchIdButton').addEventListener('click', () => {
    const searchId = document.getElementById('searchIdInput').value;
    fetch(`/api/ventas/${encodeURIComponent(searchId)}`)
      .then(response => {
        if (response.ok) {
          return response.json();
        } else {
          throw new Error('Venta no encontrada');
        }
      })
      .then(venta => {
        const tableBody = document.querySelector('#ventasTable tbody');
        tableBody.innerHTML = ''; // Limpiar la tabla antes de añadir el resultado

        addVentaToTable(venta);
      })
      .catch(error => {
        console.error('Error al buscar venta por ID:', error);
        const tableBody = document.querySelector('#ventasTable tbody');
        tableBody.innerHTML = '<tr><td colspan="11">No se encontró la venta con el ID proporcionado.</td></tr>';
      });
  });
});

function addVentaToTable(venta) {
  const tableBody = document.querySelector('#ventasTable tbody');
  const row = document.createElement('tr');
  row.innerHTML = `
    <td>${venta.ventasid}</td>
    <td>${venta.numerobastidor}</td>
    <td>${venta.vendedoresid}</td>
    <td>${venta.serviciosid}</td>
    <td>${venta.clienteid}</td>
    <td>${venta.preciocobrado}</td>
    <td>${venta.modopago}</td>
    <td>${new Date(venta.fechaentrega).toISOString().split('T')[0]}</td>
    <td>${venta.matricula}</td>
    <td>${venta.stockfabricado}</td>
    <td>
      <button onclick="editVenta(this)">✏️</button>
      <button onclick="deleteVenta(${venta.ventasid})">❌</button>
    </td>
  `;
  tableBody.appendChild(row);
}

function editVenta(button) {
  const row = button.parentNode.parentNode;
  const cells = row.querySelectorAll('td');

  // Convertir las celdas en campos editables solo para las columnas específicas
  for (let i = 5; i < cells.length - 1; i++) { // Empieza en la columna 5 (Precio Cobrado)
    const cell = cells[i];
    const value = cell.textContent;
    cell.innerHTML = `<input type="text" value="${value}">`;
  }

  // Cambiar el botón de editar a guardar
  button.textContent = '✔️';
  button.onclick = () => saveVenta(row);
}

async function validateForeignKey(endpoint, value) {
  const response = await fetch(`${endpoint}/${value}`);
  return response.ok;
}

async function validateVenta(venta) {
  const validFK = await Promise.all([
    validateForeignKey('/api/numerobastidores', venta.NumeroBastidor),
    validateForeignKey('/api/vendedores', venta.VendedoresId),
    validateForeignKey('/api/servicios', venta.ServiciosId),
    validateForeignKey('/api/clientes', venta.ClienteId),
  ]);

  if (!validFK[0]) {
    alert('Número Bastidor no válido.');
    return false;
  }
  if (!validFK[1]) {
    alert('Vendedor no válido.');
    return false;
  }
  if (!validFK[2]) {
    alert('Servicio no válido.');
    return false;
  }
  if (!validFK[3]) {
    alert('Cliente no válido.');
    return false;
  }
  if (isNaN(venta.PrecioCobrado) || venta.PrecioCobrado === '') {
    alert('Por favor, ingrese un Precio Cobrado válido.');
    return false;
  }
  if (/[^a-zA-Z\s]/.test(venta.ModoPago) || venta.ModoPago.trim() === '') {
    alert('Por favor, ingrese un Modo de Pago válido.');
    return false;
  }
  if (isNaN(Date.parse(venta.FechaEntrega))) {
    alert('Por favor, ingrese una Fecha de Entrega válida.');
    return false;
  }
  if (/[^a-zA-Z\s]/.test(venta.Matricula) || venta.Matricula.trim() === '') {
    alert('Por favor, ingrese una Matrícula válida.');
    return false;
  }
  if (isNaN(venta.StockFabricado) || venta.StockFabricado === '') {
    alert('Por favor, ingrese un Stock Fabricado válido.');
    return false;
  }

  return true;
}

async function saveVenta(row) {
  const cells = row.querySelectorAll('td');
  const id = cells[0].textContent;
  const updatedVenta = {
    NumeroBastidor: cells[1].textContent,
    VendedoresId: cells[2].textContent,
    ServiciosId: cells[3].textContent,
    ClienteId: cells[4].textContent,
    PrecioCobrado: cells[5].querySelector('input').value,
    ModoPago: cells[6].querySelector('input').value,
    FechaEntrega: cells[7].querySelector('input').value,
    Matricula: cells[8].querySelector('input').value,
    StockFabricado: cells[9].querySelector('input').value
  };

  if (!await validateVenta(updatedVenta)) {
    return;
  }

  fetch(`/api/ventas/${id}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(updatedVenta)
  })
    .then(response => response.json())
    .then(venta => {
      // Actualizar la fila con los nuevos datos
      cells[1].textContent = venta.numerobastidor;
      cells[2].textContent = venta.vendedoresid;
      cells[3].textContent = venta.serviciosid;
      cells[4].textContent = venta.clienteid;
      cells[5].textContent = venta.preciocobrado;
      cells[6].textContent = venta.modopago;
      cells[7].textContent = new Date(venta.fechaentrega).toISOString().split('T')[0];
      cells[8].textContent = venta.matricula;
      cells[9].textContent = venta.stockfabricado;

      // Cambiar el botón de guardar a editar
      const editButton = cells[10].querySelector('button');
      editButton.textContent = '✏️';
      editButton.onclick = () => editVenta(editButton);
    })
    .catch(error => console.error('Error al actualizar la venta:', error));
}

function deleteVenta(id) {
  if (confirm('¿Estás seguro de que quieres eliminar esta venta?')) {
    fetch(`/api/ventas/${id}`, {
      method: 'DELETE'
    })
      .then(response => {
        if (response.ok) {
          alert('Venta eliminada');
          deleteVentaFromTable(id); // Eliminar la fila sin recargar la página
        } else {
          alert('Error al eliminar la venta');
        }
      })
      .catch(error => console.error('Error al eliminar la venta:', error));
  }
}

function deleteVentaFromTable(id) {
  const rows = document.querySelectorAll('#ventasTable tbody tr');
  rows.forEach(row => {
    if (row.cells[0].textContent == id) {
      row.remove();
    }
  });
}
