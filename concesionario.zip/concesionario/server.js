
const express = require('express');
const path = require('path');
const ventasController = require('./controller/ventasController');

const app = express();
const PORT = process.env.PORT || 3029;

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, 'view')));

// Rutas de la API
app.get('/api/ventas', ventasController.getVentas);
app.get('/api/ventas/:id', ventasController.getVentaById);
app.get('/api/ventas/text/:text', ventasController.getVentasByText); // Nueva ruta para búsqueda por texto
app.post('/api/ventas', ventasController.addVenta);
app.put('/api/ventas/:id', ventasController.updateVenta);
app.delete('/api/ventas/:id', ventasController.deleteVenta);
app.get('/api/vendedores', ventasController.getVendedores);
app.get('/api/servicios', ventasController.getServicios);
app.get('/api/autos', ventasController.getAutos);
app.get('/api/clientes', ventasController.getClientes);


// Rutas para validar claves foráneas
app.get('/api/validate/numerobastidores/:id', ventasController.validateNumeroBastidor);
app.get('/api/validate/vendedores/:id', ventasController.validateVendedor);
app.get('/api/validate/servicios/:id', ventasController.validateServicio);
app.get('/api/validate/clientes/:id', ventasController.validateCliente);

// Servir el archivo index.html
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'view', 'index.html'));
});

// Iniciar el servidor
app.listen(PORT, () => {
  console.log(`Servidor iniciado en el puerto ${PORT}`);
});
